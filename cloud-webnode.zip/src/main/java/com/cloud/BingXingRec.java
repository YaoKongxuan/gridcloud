package com.cloud;

import com.cloud.mapper.BingMapper;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.ujmp.core.DenseMatrix;
import org.ujmp.core.Matrix;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;


public class BingXingRec extends Thread{
    private String filename;
    private Matrix juzheng;
    private Matrix flag;
    private int total;
    private int rows;
    private int cols;
    private int port;
    BingMapper bingMapper;
    public BingXingRec(String filename, int rows, int cols,int port,BingMapper bingMapper) {
        this.filename  = filename;
        this.flag = DenseMatrix.Factory.ones(rows, cols);
        this.rows = rows;
        this.cols = cols;
        this.juzheng = DenseMatrix.Factory.zeros(rows, cols);
        this.port = port;
        this.total = rows*cols;
        this.bingMapper = bingMapper;
    }

    @Override
    public void run() {
        // 接收socket程序
        DatagramSocket socketrec = null;
        try {
            socketrec = new DatagramSocket(this.port);
        } catch (SocketException e) {
            e.printStackTrace();
        }
        while(this.total!=0)
        {
            byte[] arr = new byte[1024];
            DatagramPacket packetrec = new DatagramPacket(arr, arr.length);
            try {
                socketrec.receive(packetrec);
            } catch (IOException ignored) {

            }
            byte[] arr1 = packetrec.getData();
            String res = new String(arr1).trim();
            JSONObject resjson = null;
            try {
                resjson = new JSONObject(res);
                int resrow = resjson.getInt("row");
                int rescol = resjson.getInt("col");
                if(this.flag.getAsInt(resrow,rescol)==1)
                {
                    this.flag.setAsInt(0,resrow,rescol);
                    this.juzheng.setAsDouble(resjson.getDouble("res"),resrow,rescol);
                    this.total--;
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        try {
            File writeName = new File(WebStatic.jisuanpath+this.filename); // 相对路径，如果没有则要建立一个新的文件
            writeName.createNewFile(); // 创建新文件,有同名的文件的话直接覆盖
            FileWriter writer = new FileWriter(writeName);
            BufferedWriter out = new BufferedWriter(writer);
            for(int i = 0;i<this.rows;i++)
            {
                for(int p = 0;p<this.cols;p++)
                {
                    out.write(this.juzheng.getAsString(i,p));
                    if(p!=this.cols-1)
                    {
                        out.write(" ");
                    }
                    else {
                        out.write("\n");
                    }
                }
                out.flush(); // 把缓存区内容压入文件
            }
            out.close();
            writer.close();
        } catch (IOException ioException) {
            ioException.printStackTrace();
        }
        String a[] = filename.split("[-\\.]");
        bingMapper.ChingeZhuang(a[0]+"-"+a[1],"计算结束");
        synchronized (WebStatic.ports){
            WebStatic.ports.add(this.port);
            WebStatic.ports.notifyAll();
        }
    }
}
