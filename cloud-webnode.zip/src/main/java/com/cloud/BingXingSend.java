package com.cloud;

import com.cloud.BingXingRec;
import com.cloud.WebStatic;
import com.cloud.mapper.BingMapper;
import org.json.JSONObject;
import org.ujmp.core.DenseMatrix;
import org.ujmp.core.Matrix;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.net.*;
import java.util.HashMap;
import java.util.Map;

public class BingXingSend extends Thread{
    private String filename;
    BingMapper bingMapper;
    public BingXingSend(String filename,BingMapper bingMapper) {
        this.filename = filename;
        this.bingMapper = bingMapper;
    }
    @Override
    public void run() {
        //读取文件中的两个矩阵
        int fir_rows = 0,fir_col = 0,sec_rows = 0,sec_col = 0;
        Matrix fir = null,sec = null;
        try (FileReader reader = new FileReader(WebStatic.jisuanpath+this.filename);
             BufferedReader br = new BufferedReader(reader) // 建立一个对象，它把文件内容转成计算机能读懂的语言
        ) {
            String line;
            line = br.readLine();
            String strings[] = line.split(" ");
            fir_rows = Integer.parseInt(strings[0]);
            fir_col = Integer.parseInt(strings[1]);
            sec_rows = Integer.parseInt(strings[2]);
            sec_col = Integer.parseInt(strings[3]);
            fir = DenseMatrix.Factory.zeros(fir_rows, fir_col);
            sec = DenseMatrix.Factory.zeros(sec_rows, sec_col);
            for(int i = 0;i < fir_rows;i++)
            {
                line = br.readLine();
                strings = line.split(" ");
                for(int p = 0;p < fir_col;p++)
                {
                    fir.setAsDouble(Double.parseDouble(strings[p]), i, p);
                }
            }
            for(int i = 0;i < sec_rows;i++)
            {
                line = br.readLine();
                strings = line.split(" ");
                for(int p = 0;p < sec_col;p++)
                {
                    sec.setAsDouble(Double.parseDouble(strings[p]), i, p);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        //准备发送信息,申请监听端口
        int port = 0;
        synchronized (WebStatic.ports){
            while(true)
            {
                if(WebStatic.ports.size()!=0)
                {
                    port = WebStatic.ports.get(0);
                    WebStatic.ports.remove(0);
                    break;
                }
                else
                {
                    try {
                        WebStatic.ports.wait();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        // 发送socket程序
        DatagramSocket socketsend = null;
        try {
            socketsend = new DatagramSocket();
        } catch (SocketException e) {
            e.printStackTrace();
        }
        // 接收socket程序
        DatagramSocket socketrec = null;
        try {
            socketrec = new DatagramSocket(port);
            socketrec.setSoTimeout(1000); // 设置阻塞时间
        } catch (SocketException e) {
            e.printStackTrace();
        }

        //准备接收窗口的端口
        int portrec = 0;
        synchronized (WebStatic.ports){
            while(true)
            {
                if(WebStatic.ports.size()!=0)
                {
                    portrec = WebStatic.ports.get(0);
                    WebStatic.ports.remove(0);
                    break;
                }
                else
                {
                    try {
                        WebStatic.ports.wait();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        Thread thread = new BingXingRec(this.filename,fir_rows,sec_col,portrec,bingMapper);
        thread.start();
        int rows = 0,cols = 0;
        while(rows<fir_rows)
        {
            cols = 0;
            while(cols<sec_col)
            {
                StringBuilder row_data = new StringBuilder();
                StringBuilder col_data = new StringBuilder();
                for(int i = 0;i<fir_col;i++)
                {
                    row_data.append(fir.getAsDouble(rows, i));
                    if(i!=fir_col-1)
                    {
                        row_data.append(" ");
                    }
                }
                for(int i = 0;i<sec_rows;i++)
                {
                    col_data.append(sec.getAsDouble(i, cols));
                    if(i!=sec_rows-1)
                    {
                        col_data.append(" ");
                    }
                }
                Map<String, String> map = new HashMap<>();
                map.put("port",String.valueOf(port));
                map.put("row",String.valueOf(rows));
                map.put("col",String.valueOf(cols));
                map.put("row_data", row_data.toString());
                map.put("time", "1");
                map.put("col_data",col_data.toString());
                //将json转化为String类型
                JSONObject json = new JSONObject(map);
                String jsonString = "";
                jsonString = json.toString();
                //将String转化为byte[]
                byte[] jsonByte = jsonString.getBytes();
                //建立发送数据包
                //四个参数: 包的数据  包的长度  主机对象  端口号
                DatagramPacket packetsend = null;
                try {
                    packetsend = new DatagramPacket
                            (jsonByte, jsonByte.length, InetAddress.getByName(WebStatic.net) , 50100);
                } catch (UnknownHostException e) {
                    e.printStackTrace();
                }
                //第一次发送
                try {
                    socketsend.send(packetsend);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                //接收数据包
                //接收超时就重新发送这个数据的
                byte[] arr = new byte[1024];
                DatagramPacket packetrec = new DatagramPacket(arr, arr.length);
                try {
                    socketrec.receive(packetrec);
                } catch (IOException e) {
                    continue;
                }
                //第二次发送
                map.put("port",String.valueOf(portrec));
                map.put("time", "2");
                //将json转化为String类型
                json = new JSONObject(map);
                jsonString = "";
                jsonString = json.toString();
                //将String转化为byte[]
                jsonByte = jsonString.getBytes();
                try {
                    packetsend = new DatagramPacket
                            (jsonByte, jsonByte.length, packetrec.getAddress() , 50200);
                    socketsend.send(packetsend);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                cols++;
            }
            rows++;
        }
        //释放端口
        socketrec.close();
        socketsend.close();
        synchronized (WebStatic.ports){
            WebStatic.ports.add(port);
            WebStatic.ports.notifyAll();
        }
    }
}
