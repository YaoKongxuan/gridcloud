package com.cloud;

import java.util.ArrayList;
import java.util.Arrays;

public class WebStatic {
    public static String webname = "yaokx";
    public static String net = "192.168.137.255";
    public static String jisuanpath = "F:/cloud/txt/";
    public static ArrayList<Integer> ports = new ArrayList<>(Arrays.asList(50001,50002,50003,50004,50005
    ,50006,50007,50008,50009,50010,50011,50012,50013,50014,50015,50016,50017,50018,50019,50020));

}
