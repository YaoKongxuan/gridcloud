package com.cloud.controller;

import com.cloud.WebStatic;
import com.cloud.mapper.UserMapper;
import org.apache.ibatis.ognl.DynamicSubscript;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.IncorrectCredentialsException;
import org.apache.shiro.authc.UnknownAccountException;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class Login {
    @Autowired
    UserMapper userMapper;
    //主页显示
    @RequestMapping({"/"})
    public String Index()
    {
        return "index";
    }

    // 返回登录界面
    @RequestMapping({"/login"})
    public String login()
    {
        return "login";
    }

    // 登录用户
    @RequestMapping({"/tologin"})
    public String tologin(String username, String password, Model model)
    {

        //获取当前用户
        Subject subject = SecurityUtils.getSubject();
        //封装用户的登录信息
        UsernamePasswordToken token = new UsernamePasswordToken(username,password);
        //执行登录操作
        try{
            subject.login(token);
            if(username.equals("root"))
                return "/root/zhuye";
            else
                return "/user/zhuye";
        }
        catch (UnknownAccountException e)//用户名不存在
        {
            model.addAttribute("msg","用户名错误");
            return "login";
        }
        catch (IncorrectCredentialsException e)//密码错误
        {
            model.addAttribute("msg","密码错误");
            return "login";
        }
    }
    // 返回注册界面
    @RequestMapping({"/zhuce"})
    public String zhuce()
    {
        return "zhuce";
    }
    // 返回注册界面
    @RequestMapping({"/tozhuce"})
    public String tozhuce(String username, String password, Model model)
    {
        String psw = userMapper.SearchUserPassword(username);
        if(psw == null)
        {
            userMapper.NewUser(username,password);
            model.addAttribute("msg","用户注册成功");
            return "zhuce";
        }
        else
        {
            model.addAttribute("msg","用户名已注册");
            return "zhuce";
        }
    }
}
