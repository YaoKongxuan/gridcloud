package com.cloud.controller;
import com.cloud.WebStatic;
import com.cloud.mapper.BingMapper;
import com.cloud.mapper.MachineMapper;
import com.cloud.mapper.UserMapper;
import com.cloud.BingXingSend;
import org.apache.shiro.SecurityUtils;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.*;
import java.util.HashMap;
import java.util.Map;

@Controller
public class UserController {
    @Autowired
    UserMapper userMapper;
    @Autowired
    MachineMapper machineMapper;
    @Autowired
    BingMapper bingMapper;
    //返回user用户主页
    @RequestMapping({"/user/zhuye"})
    String Index()
    {
        return "/user/zhuye";
    }
    //查看用户全部虚拟机
    @RequestMapping({"/user/searchmachine"})
    String SearchAllMachine(Model model)
    {
        model.addAttribute("name",(String) SecurityUtils.getSubject().getPrincipal());
        model.addAttribute("msg",machineMapper.SearchMachineByUsername((String) SecurityUtils.getSubject().getPrincipal()));
        return "/user/searchmachine";
    }
    //查看用户计算任务
    @RequestMapping({"/user/searchjisuan"})
    String SearchAllJisuan(Model model)
    {
        model.addAttribute("name",(String) SecurityUtils.getSubject().getPrincipal());
        model.addAttribute("msg",bingMapper.GetBingByName((String) SecurityUtils.getSubject().getPrincipal()));
        return "/user/searchjisuan";
    }
    //新建虚拟机
    @RequestMapping({"/user/newmachine"})
    String NewMachine(Model model)
    {
        model.addAttribute("name",(String) SecurityUtils.getSubject().getPrincipal());
        return "/user/newmachine";
    }
    @RequestMapping({"/user/tonewmachine"})
    String ToNewMachine(String hostname,String cpu,String hd,String memory,Model model)
    {
        String name = machineMapper.NoSameName((String) SecurityUtils.getSubject().getPrincipal()+hostname);
        if(name != null)
        {
            model.addAttribute("name",(String) SecurityUtils.getSubject().getPrincipal());
            model.addAttribute("msg","虚拟机名称重复,请重新输入");
            return "/user/newmachine";
        }
        //1.创建对象
        //构造数据报套接字并将其绑定到本地主机上任何可用的端口。
        DatagramSocket socketsend = null;
        try {
            socketsend = new DatagramSocket();
        } catch (SocketException e) {
            e.printStackTrace();
        }
        //2.打包
        int port = 0;
        synchronized (WebStatic.ports){
            while(true)
            {
                if(WebStatic.ports.size()!=0)
                {
                    port = WebStatic.ports.get(0);
                    WebStatic.ports.remove(0);
                    break;
                }
                else
                {
                    try {
                        WebStatic.ports.wait();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        Map<String, String> map = new HashMap<>();
        map.put("webname",WebStatic.webname);
        map.put("username",(String) SecurityUtils.getSubject().getPrincipal());
        map.put("hostname",hostname);
        map.put("hd",hd);
        map.put("memory",memory);
        map.put("cpu",cpu);
        map.put("port",String.valueOf(port));
        map.put("type","new");
        //将json转化为String类型
        JSONObject json = new JSONObject(map);
        String jsonString = "";
        jsonString = json.toString();
        //将String转化为byte[]
        byte[] jsonByte = jsonString.getBytes();
        //四个参数: 包的数据  包的长度  主机对象  端口号
        DatagramPacket packetsend = null;
        try {
            packetsend = new DatagramPacket
                    (jsonByte, jsonByte.length, InetAddress.getByName(WebStatic.net) , 50000);
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }
        //第一次发送
        try {
            socketsend.send(packetsend);
        } catch (IOException e) {
            e.printStackTrace();
        }

        //1
        DatagramSocket socketrec = null;
        try {
            socketrec = new DatagramSocket(port);
        } catch (SocketException e) {
            e.printStackTrace();
        }
        //2
        byte[] arr = new byte[1024];
        DatagramPacket packetrec = new DatagramPacket(arr, arr.length);
        //3 当程序运行起来之后,receive方法会一直处于监听状态
        try {
            socketrec.receive(packetrec);
        } catch (IOException e) {
            e.printStackTrace();
        }
        //第二次发送
        try {
            packetsend = new DatagramPacket
                    (jsonByte, jsonByte.length, packetrec.getAddress() , 50000);
            socketsend.send(packetsend);
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            socketrec.receive(packetrec);
        } catch (IOException e) {
            e.printStackTrace();
        }
        byte[] arr1 = packetrec.getData();
        String ip = new String(arr1).trim();
        //4.关闭资源
        socketrec.close();
        socketsend.close();
        synchronized (WebStatic.ports){
            WebStatic.ports.add(port);
            WebStatic.ports.notifyAll();
        }
        machineMapper.NewMachine((String) SecurityUtils.getSubject().getPrincipal()+hostname,(String) SecurityUtils.getSubject().getPrincipal(),hostname,ip,memory,cpu,hd,"close");
        userMapper.UpdateMachineNums((String) SecurityUtils.getSubject().getPrincipal(),userMapper.UserMachineNums((String) SecurityUtils.getSubject().getPrincipal())+1);
        model.addAttribute("name",(String) SecurityUtils.getSubject().getPrincipal());
        model.addAttribute("msg","虚拟机创建成功");
        return "/user/newmachine";
    }
    //开启虚拟机
    @RequestMapping({"/user/openmachine"})
    String OpenMachine(Model model)
    {
        model.addAttribute("name",(String) SecurityUtils.getSubject().getPrincipal());
        return "/user/openmachine";
    }
    @RequestMapping({"/user/toopenmachine"})
    String ToOpenMachine(Model model,String hostname)
    {
        String name = machineMapper.SerachZhuangtai((String) SecurityUtils.getSubject().getPrincipal()+hostname);
        if(name == null)
        {
            model.addAttribute("name",(String) SecurityUtils.getSubject().getPrincipal());
            model.addAttribute("msg","没有该名称的虚拟机");
            return "/user/openmachine";
        }
        //1.创建对象
        //构造数据报套接字并将其绑定到本地主机上任何可用的端口。
        DatagramSocket socketsend = null;
        try {
            socketsend = new DatagramSocket();
        } catch (SocketException e) {
            e.printStackTrace();
        }
        //2.打包
        int port = 0;
        synchronized (WebStatic.ports){
            while(true)
            {
                if(WebStatic.ports.size()!=0)
                {
                    port = WebStatic.ports.get(0);
                    WebStatic.ports.remove(0);
                    break;
                }
                else
                {
                    try {
                        WebStatic.ports.wait();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        Map<String, String> map = new HashMap<>();
        map.put("webname",WebStatic.webname);
        map.put("username",(String) SecurityUtils.getSubject().getPrincipal());
        map.put("hostname",hostname);
        map.put("port",String.valueOf(port));
        map.put("type","open");
        //将json转化为String类型
        JSONObject json = new JSONObject(map);
        String jsonString = "";
        jsonString = json.toString();
        //将String转化为byte[]
        byte[] jsonByte = jsonString.getBytes();
        //四个参数: 包的数据  包的长度  主机对象  端口号
        DatagramPacket packetsend = null;
        try {
            packetsend = new DatagramPacket
                    (jsonByte, jsonByte.length, InetAddress.getByName(WebStatic.net) , 50000);
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }
        //第一次发送
        try {
            socketsend.send(packetsend);
        } catch (IOException e) {
            e.printStackTrace();
        }
        DatagramSocket socketrec = null;
        try {
            socketrec = new DatagramSocket(port);
        } catch (SocketException e) {
            e.printStackTrace();
        }
        //2
        byte[] arr = new byte[1024];
        DatagramPacket packetrec = new DatagramPacket(arr, arr.length);
        //3 当程序运行起来之后,receive方法会一直处于监听状态
        try {
            socketrec.receive(packetrec);
        } catch (IOException e) {
            e.printStackTrace();
        }
        socketrec.close();
        socketsend.close();
        synchronized (WebStatic.ports){
            WebStatic.ports.add(port);
            WebStatic.ports.notifyAll();
        }
        machineMapper.UpdateZhuantai((String) SecurityUtils.getSubject().getPrincipal()+hostname,"open");
        model.addAttribute("name",(String) SecurityUtils.getSubject().getPrincipal());
        model.addAttribute("msg","虚拟机开机成功");
        return "/user/openmachine";
    }
    //关闭虚拟机
    @RequestMapping({"/user/closemachine"})
    String CloseMachine(Model model)
    {
        model.addAttribute("name",(String) SecurityUtils.getSubject().getPrincipal());
        return "/user/closemachine";
    }
    @RequestMapping({"/user/toclosemachine"})
    String ToCloseMachine(Model model,String hostname)
    {
        String name = machineMapper.SerachZhuangtai((String) SecurityUtils.getSubject().getPrincipal()+hostname);
        if(name == null)
        {
            model.addAttribute("name",(String) SecurityUtils.getSubject().getPrincipal());
            model.addAttribute("msg","没有该名称的虚拟机");
            return "/user/closemachine";
        }
        //1.创建对象
        //构造数据报套接字并将其绑定到本地主机上任何可用的端口。
        DatagramSocket socketsend = null;
        try {
            socketsend = new DatagramSocket();
        } catch (SocketException e) {
            e.printStackTrace();
        }
        //2.打包
        int port = 0;
        synchronized (WebStatic.ports){
            while(true)
            {
                if(WebStatic.ports.size()!=0)
                {
                    port = WebStatic.ports.get(0);
                    WebStatic.ports.remove(0);
                    break;
                }
                else
                {
                    try {
                        WebStatic.ports.wait();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        Map<String, String> map = new HashMap<>();
        map.put("webname",WebStatic.webname);
        map.put("username",(String) SecurityUtils.getSubject().getPrincipal());
        map.put("hostname",hostname);
        map.put("port",String.valueOf(port));
        map.put("type","close");
        //将json转化为String类型
        JSONObject json = new JSONObject(map);
        String jsonString = "";
        jsonString = json.toString();
        //将String转化为byte[]
        byte[] jsonByte = jsonString.getBytes();
        //四个参数: 包的数据  包的长度  主机对象  端口号
        DatagramPacket packetsend = null;
        try {
            packetsend = new DatagramPacket
                    (jsonByte, jsonByte.length, InetAddress.getByName(WebStatic.net) , 50000);
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }
        //第一次发送
        try {
            socketsend.send(packetsend);
        } catch (IOException e) {
            e.printStackTrace();
        }
        DatagramSocket socketrec = null;
        try {
            socketrec = new DatagramSocket(port);
        } catch (SocketException e) {
            e.printStackTrace();
        }
        //2
        byte[] arr = new byte[1024];
        DatagramPacket packetrec = new DatagramPacket(arr, arr.length);
        //3 当程序运行起来之后,receive方法会一直处于监听状态
        try {
            socketrec.receive(packetrec);
        } catch (IOException e) {
            e.printStackTrace();
        }
        socketrec.close();
        socketsend.close();
        synchronized (WebStatic.ports){
            WebStatic.ports.add(port);
            WebStatic.ports.notifyAll();
        }
        machineMapper.UpdateZhuantai((String) SecurityUtils.getSubject().getPrincipal()+hostname,"close");
        model.addAttribute("name",(String) SecurityUtils.getSubject().getPrincipal());
        model.addAttribute("msg","虚拟机关机成功");
        return "/user/closemachine";
    }
    //删除虚拟机
    @RequestMapping({"/user/delmachine"})
    String DelMachine(Model model)
    {
        model.addAttribute("name",(String) SecurityUtils.getSubject().getPrincipal());
        return "/user/delmachine";
    }
    @RequestMapping({"/user/todelmachine"})
    String ToDelMachine(Model model,String hostname)
    {
        String name = machineMapper.SerachZhuangtai((String) SecurityUtils.getSubject().getPrincipal()+hostname);
        if(name == null)
        {
            model.addAttribute("name",(String) SecurityUtils.getSubject().getPrincipal());
            model.addAttribute("msg","没有该名称的虚拟机");
            return "/user/delmachine";
        }
        //1.创建对象
        //构造数据报套接字并将其绑定到本地主机上任何可用的端口。
        DatagramSocket socketsend = null;
        try {
            socketsend = new DatagramSocket();
        } catch (SocketException e) {
            e.printStackTrace();
        }
        //2.打包
        int port = 0;
        synchronized (WebStatic.ports){
            while(true)
            {
                if(WebStatic.ports.size()!=0)
                {
                    port = WebStatic.ports.get(0);
                    WebStatic.ports.remove(0);
                    break;
                }
                else
                {
                    try {
                        WebStatic.ports.wait();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        Map<String, String> map = new HashMap<>();
        map.put("webname",WebStatic.webname);
        map.put("username",(String) SecurityUtils.getSubject().getPrincipal());
        map.put("hostname",hostname);
        map.put("port",String.valueOf(port));
        map.put("type","del");
        //将json转化为String类型
        JSONObject json = new JSONObject(map);
        String jsonString = "";
        jsonString = json.toString();
        //将String转化为byte[]
        byte[] jsonByte = jsonString.getBytes();
        //四个参数: 包的数据  包的长度  主机对象  端口号
        DatagramPacket packetsend = null;
        try {
            packetsend = new DatagramPacket
                    (jsonByte, jsonByte.length, InetAddress.getByName(WebStatic.net) , 50000);
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }
        //第一次发送
        try {
            socketsend.send(packetsend);
        } catch (IOException e) {
            e.printStackTrace();
        }
        DatagramSocket socketrec = null;
        try {
            socketrec = new DatagramSocket(port);
        } catch (SocketException e) {
            e.printStackTrace();
        }
        //2
        byte[] arr = new byte[1024];
        DatagramPacket packetrec = new DatagramPacket(arr, arr.length);
        //3 当程序运行起来之后,receive方法会一直处于监听状态
        try {
            socketrec.receive(packetrec);
        } catch (IOException e) {
            e.printStackTrace();
        }
        socketrec.close();
        socketsend.close();
        synchronized (WebStatic.ports){
            WebStatic.ports.add(port);
            WebStatic.ports.notifyAll();
        }
        userMapper.UpdateMachineNums((String) SecurityUtils.getSubject().getPrincipal(),userMapper.UserMachineNums((String) SecurityUtils.getSubject().getPrincipal())-1);
        machineMapper.DelMachine((String) SecurityUtils.getSubject().getPrincipal()+hostname);
        model.addAttribute("name",(String) SecurityUtils.getSubject().getPrincipal());
        model.addAttribute("msg","虚拟机删除成功");
        return "/user/closemachine";
    }
    //上传文件
    @RequestMapping({"/user/uptxt"})
    String UpTxt(Model model)
    {
        model.addAttribute("name",(String) SecurityUtils.getSubject().getPrincipal());
        return "/user/uptxt";
    }
    @RequestMapping("/user/upload")
    String upload(@RequestParam("file") MultipartFile file,Model model){
        model.addAttribute("name",(String) SecurityUtils.getSubject().getPrincipal());
        if (file.isEmpty()){
            model.addAttribute("msg","未选择文件");
            return "/user/uptxt";
        }/*
        String filename = file.getOriginalFilename(); //获取上传文件原来的名称

        String a[] = file.getOriginalFilename().split("[-\\.]");
        File temp = new File(WebStatic.jisuanpath);
        String only = bingMapper.GetName((String) SecurityUtils.getSubject().getPrincipal()+"-"+a[0]);
        if(only != null)
        {
            model.addAttribute("msg","已创建同名任务");
            return "/user/uptxt";
        }
        if (!temp.exists()){
            temp.mkdirs();
        }
        File localFile = new File(WebStatic.jisuanpath+(String) SecurityUtils.getSubject().getPrincipal()+"-"+filename);
        try {
            file.transferTo(localFile); //把上传的文件保存至本地
        }catch (IOException e){
            e.printStackTrace();
            model.addAttribute("msg","上传文件失败");
            return "/user/uptxt";
        }
        Thread thread = new BingXingSend((String) SecurityUtils.getSubject().getPrincipal()+"-"+filename,bingMapper);
        thread.start();

        bingMapper.NewBing((String) SecurityUtils.getSubject().getPrincipal()+"-"+a[0],a[0],"计算中",(String) SecurityUtils.getSubject().getPrincipal());
        model.addAttribute("msg","上传文件成功,正在计算中");
        return "/user/uptxt";
    }
    //下载文件
    @RequestMapping({"/user/download"})
    String DownTxt(Model model)
    {
        model.addAttribute("name",(String) SecurityUtils.getSubject().getPrincipal());
        return "/user/download";
    }
    //实现Spring Boot 的文件下载功能，映射网址为/download
    @RequestMapping("/user/todownload")
    public String ToDownTxt(HttpServletRequest request,HttpServletResponse response,String filename,Model model) throws UnsupportedEncodingException {
        model.addAttribute("name",(String) SecurityUtils.getSubject().getPrincipal());
        String only = bingMapper.GetName((String) SecurityUtils.getSubject().getPrincipal()+"-"+filename);
        if(only == null)
        {
            model.addAttribute("msg","文件名错误,没有该文件");
            return "/user/download";
        }
        String downname = filename+"4"+".txt";
        filename = filename+".txt";

        filename = WebStatic.jisuanpath+(String) SecurityUtils.getSubject().getPrincipal()+"-"+filename;
        File file = new File(filename);
        // 配置文件下载
        response.setHeader("content-type", "application/octet-stream");
        response.setContentType("application/octet-stream");
        // 下载文件能正常显示中文
        response.setHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode(WebStatic.jisuanpath+downname, "UTF-8"));
        byte[] buffer = new byte[1024];
        FileInputStream fis = null;
        BufferedInputStream bis = null;
        try {
            fis = new FileInputStream(file);
            bis = new BufferedInputStream(fis);
            OutputStream os = response.getOutputStream();
            int i = bis.read(buffer);
            while (i != -1) {
                os.write(buffer, 0, i);
                i = bis.read(buffer);
            }
            System.out.println("Download the song successfully!");
        }
        catch (Exception e) {
            e.printStackTrace();
            System.out.println("Download the song failed!");
        }
        finally {
            if (bis != null) {
                try {
                    bis.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (fis != null) {
                try {
                    fis.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        model.addAttribute("msg","文件名错误,没有该文件");
        return "/user/download";*/
        model.addAttribute("msg","功能暂时未实现");
        return "/user/download";
    }
}
