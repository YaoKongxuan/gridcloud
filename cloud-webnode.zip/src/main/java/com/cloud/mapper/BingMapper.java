package com.cloud.mapper;

import com.cloud.pojo.Bing;
import com.cloud.pojo.Machine;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

//表示的这是一个mybaits的map类
@Mapper
@Repository
public interface BingMapper {
    Void NewBing(String onlyname,String name,String zhuang_tai,String username);
    Void ChingeZhuang(String onlyname,String zhuang_tai);
    String GetName(String onlyname);
    List<Bing> GetBingByName(String username);
}
