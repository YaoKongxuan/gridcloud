package com.cloud.mapper;

import com.cloud.pojo.Machine;
import com.cloud.pojo.User;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;
import java.util.*;
//表示的这是一个mybaits的map类
@Mapper
@Repository
public interface MachineMapper {
    Void NewMachine(String onlyname,String username,String hostname,String ip,String memory,String cpu,String hd,String zhuangtai);
    String NoSameName(String onlyname);
    String SerachZhuangtai(String onlyname);
    List<Machine> SearchMachineByUsername(String username);
    Void UpdateZhuantai(String onlyname,String zhuangtai);
    Void DelMachine(String onlyname);
}
