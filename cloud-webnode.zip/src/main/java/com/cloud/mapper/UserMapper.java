package com.cloud.mapper;

import com.cloud.pojo.User;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;
import java.util.*;

//表示的这是一个mybaits的map类
@Mapper
@Repository
public interface UserMapper {
    String SearchUserPassword(String username);
    List<User> SearchAllUser();

    Void NewUser(String username,String pwd);
    int UserMachineNums(String username);
    Void UpdateMachineNums(String username,int nums);
}
