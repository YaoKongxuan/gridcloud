package com.cloud.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Bing {
    private String onlyname;
    private String username;
    private String name;
    private String zhuang_tai;
}
