package com.cloud.pojo;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Machine
{
    private String onlyname;//唯一名称
    private String username;//所属用户名称
    private String hostname;//虚拟机名称
    private String ip;//虚拟机名称
    private String zhuang_tai;//虚拟机状态
    private int memory;//内存大小 MB单位
    private int cpu;//cpu数量
    private int hd;//硬盘大小 MB单位
}
